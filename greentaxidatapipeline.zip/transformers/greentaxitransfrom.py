if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

import pandas as pd

@transformer
def transform(data, *args, **kwargs):
    # Specify your transformation logic here
    


    nan_count = data['passenger_count'].isna().sum()

    print(f'this is the count of missing values', nan_count)

    #vendor_unique = data[VendorID].unique()
    #print(sorted(vendor_unique))
    
    
    zero_passengers_df = data[data['passenger_count'].isin([0])]
    zero_passengers_count = zero_passengers_df['passenger_count'].count()
    non_zero_passengers_df = data[data['passenger_count'] > 0]
    non_zero_passengers_count = non_zero_passengers_df['passenger_count'].count()
    print(f'Preprocessing: records with zero passengers: {zero_passengers_count}')
    print(f'Preprocessing: records with 1 passenger or more: {non_zero_passengers_count}')
    notrip_df = non_zero_passengers_df[non_zero_passengers_df['trip_distance'].isin([0])]
    notrip_count = notrip_df['passenger_count'].count()
    print(f'Preprocessing: records with no trip: {notrip_count}')
    nopass_notrip_df = non_zero_passengers_df[non_zero_passengers_df['trip_distance'] > 0]
    nopass_notrip_df.columns = (nopass_notrip_df.columns
                        .str.replace(' ', '_')
                        .str.lower()
        )
    nopass_notrip_df_count = nopass_notrip_df['passenger_count'].count()
    print(f'Preprocessing: records with 1 passenger or more and trips: {nopass_notrip_df_count}')


    vendor_unique = nopass_notrip_df['vendorid'].unique()
    print(sorted(vendor_unique))

    fullysorted_df = nopass_notrip_df[nopass_notrip_df['vendorid'].isin(vendor_unique)]
    sortednan_count = fullysorted_df ['vendorid'].isna().sum()

    print(f'this is the count of missing values', sortednan_count)

    return fullysorted_df 


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output['passenger_count'].isin([0]).sum() == 0, 'There are rides with zero passengers'
